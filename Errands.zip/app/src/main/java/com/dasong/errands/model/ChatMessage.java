package com.dasong.errands.model;

public class ChatMessage {
}
